Desktop Pet - Portable Version
==============================

This is a portable version of the Desktop Pet application that works
without requiring Java to be installed on the target machine.

Files included:
- AdvancedDesktopPet.jar: The main application
- DesktopPet.exe.bat: Main launcher script
- DesktopPet.exe: Executable wrapper (created by create_exe.ps1)
- minimal-jre/: Embedded Java Runtime Environment
- Image/: Application images and sprites
- music/: Application music files
- chibi01.ico: Application icon

How to use:
1. Double-click 'DesktopPet.exe' to start the application
2. Or double-click 'DesktopPet.exe.bat' as alternative
3. Run 'create-shortcut.bat' to create a desktop shortcut
4. The application will work without installing Java

To create the EXE file:
1. Right-click on 'create_exe.ps1' and select "Run with PowerShell"
2. This will create DesktopPet.exe from the batch file

Requirements:
- Windows 7 or later
- No Java installation required (uses embedded JRE)

Troubleshooting:
- If the app doesn't start, try running 'DesktopPet.exe.bat' from command prompt
- Make sure all files are in the same folder
- Check that Windows Defender or antivirus isn't blocking the application
- If you get "execution policy" errors, run: Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

Features:
- Desktop pet with animations
- Horror mode with enemies
- Music system
- Cross-screen movement
- Settings panel
- System tray integration
